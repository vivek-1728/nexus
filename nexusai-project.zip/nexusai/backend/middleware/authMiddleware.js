/**
 * middleware/authMiddleware.js
 *
 * The 'protect' middleware:
 * 1. Reads the JWT from the Authorization header
 * 2. Verifies it's valid and not expired
 * 3. Attaches the userId to req so routes can use it
 */

const jwt = require("jsonwebtoken");

const protect = (req, res, next) => {
  // JWT is sent as: "Authorization: Bearer <token>"
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({
      error: "Not authorized. Please log in.",
    });
  }

  const token = authHeader.split(" ")[1];

  try {
    // Verify the token — throws if invalid or expired
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = decoded.id; // Attach user ID to request
    next(); // Continue to the actual route handler
  } catch (error) {
    return res.status(401).json({
      error: "Invalid or expired token. Please log in again.",
    });
  }
};

module.exports = { protect };
