/**
 * pages/ChatPage.jsx
 *
 * Full-featured AI chat interface.
 * Maintains conversation history and streams responses.
 */

import { useState, useRef, useEffect } from "react";
import { Send, Sparkles, User, RotateCcw, Copy, Check } from "lucide-react";
import useAI from "../hooks/useAI";
import LoadingSpinner from "../components/ui/LoadingSpinner";

// ── Message Bubble ────────────────────────────────────
const MessageBubble = ({ message }) => {
  const [copied, setCopied] = useState(false);
  const isUser = message.role === "user";

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className={`flex gap-3 ${isUser ? "flex-row-reverse" : "flex-row"}`}>
      {/* Avatar */}
      <div className={`
        w-8 h-8 rounded-xl flex-shrink-0 flex items-center justify-center
        ${isUser
          ? "bg-brand-500/30 border border-brand-500/30"
          : "bg-gradient-to-br from-brand-500 to-purple-600"
        }
      `}>
        {isUser
          ? <User className="w-4 h-4 text-brand-300" />
          : <Sparkles className="w-4 h-4 text-white" />
        }
      </div>

      {/* Bubble */}
      <div className={`
        group max-w-[80%] relative
        ${isUser ? "items-end" : "items-start"}
        flex flex-col
      `}>
        <div className={`
          px-4 py-3 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap
          ${isUser
            ? "bg-brand-500/25 border border-brand-500/20 text-white/90 rounded-tr-sm"
            : "glass-card border border-white/8 text-white/70 rounded-tl-sm"
          }
        `}>
          {message.content}
        </div>

        {/* Copy button (visible on hover for AI messages) */}
        {!isUser && (
          <button
            onClick={handleCopy}
            className="mt-1 flex items-center gap-1 text-xs text-white/20 hover:text-white/50 opacity-0 group-hover:opacity-100 transition-all"
          >
            {copied ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
            {copied ? "Copied!" : "Copy"}
          </button>
        )}
      </div>
    </div>
  );
};

// ── Typing Indicator ──────────────────────────────────
const TypingIndicator = () => (
  <div className="flex gap-3">
    <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-brand-500 to-purple-600 flex items-center justify-center flex-shrink-0">
      <Sparkles className="w-4 h-4 text-white" />
    </div>
    <div className="glass-card border border-white/8 rounded-2xl rounded-tl-sm px-4 py-3 flex items-center gap-1.5">
      {[0, 1, 2].map((i) => (
        <div
          key={i}
          className="w-1.5 h-1.5 rounded-full bg-brand-400 animate-bounce"
          style={{ animationDelay: `${i * 0.15}s` }}
        />
      ))}
    </div>
  </div>
);

// ── Suggested Prompts ─────────────────────────────────
const SUGGESTIONS = [
  "Write a catchy intro for a tech blog",
  "Give me 5 social media post ideas for a coffee shop",
  "Help me write a professional email to a client",
  "What are the best practices for React performance?",
];

// ── Chat Page ─────────────────────────────────────────
export default function ChatPage() {
  const { sendMessage, loading } = useAI();
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  // Auto-scroll to newest message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const handleSend = async (text) => {
    const userText = text || input.trim();
    if (!userText || loading) return;

    setInput("");

    // Add user message to conversation
    const updatedMessages = [
      ...messages,
      { role: "user", content: userText },
    ];
    setMessages(updatedMessages);

    // Format for API (only send role + content)
    const apiMessages = updatedMessages.map(({ role, content }) => ({
      role,
      content,
    }));

    // Get AI response
    const reply = await sendMessage(apiMessages);
    if (reply) {
      setMessages((prev) => [...prev, { role: "assistant", content: reply }]);
    }

    inputRef.current?.focus();
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const clearChat = () => setMessages([]);

  return (
    <div className="flex flex-col h-full max-h-[calc(100vh-0px)] p-4 md:p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="font-display font-bold text-xl text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-brand-400" />
            AI Chat
          </h1>
          <p className="text-sm text-white/40 mt-0.5">Ask anything. Get intelligent answers.</p>
        </div>
        {messages.length > 0 && (
          <button
            onClick={clearChat}
            className="flex items-center gap-1.5 text-sm text-white/30 hover:text-white/60 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Clear
          </button>
        )}
      </div>

      {/* Messages area */}
      <div className="flex-1 overflow-y-auto rounded-2xl glass-card border border-white/8 p-4 md:p-6 space-y-4 mb-4">
        {messages.length === 0 ? (
          /* Empty state with suggestions */
          <div className="h-full flex flex-col items-center justify-center text-center py-8">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-brand-500 to-purple-600 flex items-center justify-center mb-4 shadow-lg shadow-brand-500/20 animate-float">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <h2 className="font-display font-semibold text-white mb-2">How can I help?</h2>
            <p className="text-sm text-white/40 mb-8 max-w-sm">
              Ask me to write content, answer questions, brainstorm ideas, or anything else.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 w-full max-w-lg">
              {SUGGESTIONS.map((suggestion, i) => (
                <button
                  key={i}
                  onClick={() => handleSend(suggestion)}
                  className="text-left text-sm px-4 py-3 rounded-xl glass-card border border-white/8 text-white/50 hover:text-white hover:border-white/20 transition-all duration-200"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <>
            {messages.map((msg, i) => (
              <MessageBubble key={i} message={msg} />
            ))}
            {loading && <TypingIndicator />}
            <div ref={messagesEndRef} />
          </>
        )}
      </div>

      {/* Input area */}
      <div className="glass-card border border-white/10 rounded-2xl p-3 flex items-end gap-3">
        <textarea
          ref={inputRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Message NexusAI… (Enter to send, Shift+Enter for new line)"
          rows={1}
          className="flex-1 bg-transparent text-sm text-white placeholder-white/25 outline-none resize-none leading-relaxed max-h-32 py-1"
          style={{ scrollbarWidth: "none" }}
        />
        <button
          onClick={() => handleSend()}
          disabled={!input.trim() || loading}
          className="btn-primary p-2.5 flex-shrink-0 rounded-xl disabled:opacity-40"
        >
          {loading ? (
            <LoadingSpinner size="sm" />
          ) : (
            <Send className="w-4 h-4" />
          )}
        </button>
      </div>
    </div>
  );
}
