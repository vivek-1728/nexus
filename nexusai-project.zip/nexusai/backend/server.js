/**
 * server.js — NexusAI Express Server
 *
 * Entry point for the backend. Sets up middleware,
 * connects routes, and starts listening.
 */

require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");

const authRoutes = require("./routes/auth");
const aiRoutes = require("./routes/ai");
const { errorHandler } = require("./middleware/errorHandler");

const app = express();
const PORT = process.env.PORT || 5000;

// ── Security Middleware ──────────────────────────
// helmet adds security HTTP headers automatically
app.use(helmet());

// CORS: only allow requests from our frontend
app.use(
  cors({
    origin: process.env.FRONTEND_URL || "http://localhost:5173",
    credentials: true,
  })
);

// ── Body Parsing ─────────────────────────────────
app.use(express.json({ limit: "10kb" })); // Limit request body size

// ── Rate Limiting ────────────────────────────────
// Prevent brute-force and abuse: max 100 requests per 15 minutes
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: { error: "Too many requests, please try again later." },
});
app.use("/api", limiter);

// Stricter limiter for AI endpoints (they cost money!)
const aiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 10,
  message: { error: "AI request limit reached. Please wait a moment." },
});
app.use("/api/ai", aiLimiter);

// ── Routes ───────────────────────────────────────
app.use("/api/auth", authRoutes);
app.use("/api/ai", aiRoutes);

// Health check — useful for deployment platforms
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV,
  });
});

// ── Global Error Handler ─────────────────────────
// Must be LAST middleware
app.use(errorHandler);

// ── Start Server ─────────────────────────────────
app.listen(PORT, () => {
  console.log(`✅ NexusAI server running on http://localhost:${PORT}`);
  console.log(`   Environment: ${process.env.NODE_ENV}`);
});
