/**
 * pages/LandingPage.jsx
 *
 * The public marketing landing page.
 * Sections: Navbar → Hero → Features → How It Works → Testimonials → CTA → Footer
 */

import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
  Sparkles, Wand2, MessageSquare, Zap, Shield, BarChart3,
  ArrowRight, Check, Star, Menu, X, ChevronRight,
} from "lucide-react";

// ── Data ──────────────────────────────────────────────
const FEATURES = [
  {
    icon: Wand2,
    title: "AI Content Generator",
    desc: "Create blog posts, emails, social content, and product descriptions in seconds with GPT-4 powered generation.",
    color: "from-violet-500 to-brand-500",
  },
  {
    icon: MessageSquare,
    title: "Intelligent Chat Assistant",
    desc: "Have a real conversation with your AI. Ask questions, brainstorm ideas, get feedback on your writing.",
    color: "from-cyan-500 to-blue-500",
  },
  {
    icon: Zap,
    title: "Instant Results",
    desc: "No waiting. Generate professional-quality content in under 5 seconds, ready to copy and use.",
    color: "from-amber-400 to-orange-500",
  },
  {
    icon: Shield,
    title: "Secure & Private",
    desc: "Your content and conversations are encrypted and private. We never use your data to train AI models.",
    color: "from-green-400 to-emerald-500",
  },
  {
    icon: BarChart3,
    title: "Track Your Work",
    desc: "Dashboard with usage analytics, content history, and insights on your most-used features.",
    color: "from-pink-500 to-rose-500",
  },
  {
    icon: Sparkles,
    title: "Multiple Content Types",
    desc: "Blog posts, social media, emails, product descriptions, ad copy — all from one platform.",
    color: "from-indigo-500 to-purple-600",
  },
];

const TESTIMONIALS = [
  {
    name: "Priya Sharma",
    role: "Freelance Content Writer",
    avatar: "PS",
    rating: 5,
    text: "NexusAI cut my writing time in half. I used to spend 3 hours on a blog post, now I have a great draft in 20 minutes. The quality is genuinely impressive.",
  },
  {
    name: "Marcus Chen",
    role: "Marketing Director",
    avatar: "MC",
    rating: 5,
    text: "We've tried 5 different AI tools. NexusAI is the only one that consistently produces on-brand, high-quality copy. ROI in the first week.",
  },
  {
    name: "Aisha Patel",
    role: "E-commerce Founder",
    avatar: "AP",
    rating: 5,
    text: "Product descriptions used to be a bottleneck. Now I generate and tweak 20 descriptions before my morning coffee. It's transformed my workflow.",
  },
];

const STEPS = [
  { step: "01", title: "Create your account", desc: "Sign up free in 30 seconds. No credit card required." },
  { step: "02", title: "Choose your task", desc: "Pick from chat, generation, or improvement tools." },
  { step: "03", title: "Get AI-powered results", desc: "Review, edit, and use your content instantly." },
];

// ── Sub-components ────────────────────────────────────
const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "py-3 backdrop-blur-xl border-b border-white/10" : "py-5"
      }`}
      style={scrolled ? { background: "rgba(13, 13, 20, 0.9)" } : {}}
    >
      <div className="max-w-6xl mx-auto px-6 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-brand-500 to-purple-600 flex items-center justify-center shadow-lg shadow-brand-500/30">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <span className="font-display font-bold text-white text-lg tracking-tight">NexusAI</span>
        </Link>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-8">
          {["Features", "How It Works", "Testimonials"].map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase().replace(/\s/g, "-")}`}
              className="text-sm text-white/50 hover:text-white transition-colors"
            >
              {item}
            </a>
          ))}
        </div>

        {/* CTA Buttons */}
        <div className="hidden md:flex items-center gap-3">
          <Link to="/login" className="btn-ghost text-sm px-4 py-2">Sign in</Link>
          <Link to="/register" className="btn-primary text-sm px-4 py-2 flex items-center gap-1.5">
            Get started <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {/* Mobile menu button */}
        <button
          className="md:hidden text-white/60 hover:text-white"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden mt-3 mx-4 p-4 rounded-2xl glass-card border border-white/10 space-y-3">
          {["Features", "How It Works", "Testimonials"].map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase().replace(/\s/g, "-")}`}
              className="block text-sm text-white/60 hover:text-white py-1"
              onClick={() => setMenuOpen(false)}
            >
              {item}
            </a>
          ))}
          <div className="flex flex-col gap-2 pt-2 border-t border-white/10">
            <Link to="/login" className="btn-ghost text-sm text-center">Sign in</Link>
            <Link to="/register" className="btn-primary text-sm text-center">Get started free</Link>
          </div>
        </div>
      )}
    </nav>
  );
};

// ── Main Landing Page ─────────────────────────────────
export default function LandingPage() {
  return (
    <div className="min-h-screen bg-[#0d0d14] text-white overflow-x-hidden">
      <Navbar />

      {/* ── Hero ─────────────────────────────────── */}
      <section className="relative min-h-screen flex flex-col items-center justify-center px-6 pt-24 pb-16 text-center">
        {/* Background glow orbs */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-brand-600/20 rounded-full blur-[120px] animate-glow-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-purple-600/15 rounded-full blur-[100px] animate-glow-pulse delay-300" />
        </div>

        {/* Badge */}
        <div className="animate-fade-up mb-8">
          <span className="section-badge gap-1.5">
            <Sparkles className="w-3 h-3" />
            Powered by GPT-4 · Built for creators
          </span>
        </div>

        {/* Headline */}
        <h1 className="animate-fade-up delay-100 font-display font-bold text-5xl md:text-7xl leading-tight tracking-tight max-w-4xl mx-auto mb-6">
          Create content that{" "}
          <span className="gradient-text">actually converts</span>
          <br />with AI
        </h1>

        {/* Subheadline */}
        <p className="animate-fade-up delay-200 text-lg md:text-xl text-white/50 max-w-2xl mx-auto mb-10 leading-relaxed">
          NexusAI is your intelligent content studio. Generate blogs, emails,
          social posts, and more — in seconds, not hours.
        </p>

        {/* CTA Buttons */}
        <div className="animate-fade-up delay-300 flex flex-col sm:flex-row items-center gap-4 mb-16">
          <Link
            to="/register"
            className="btn-primary flex items-center gap-2 px-8 py-4 text-base"
          >
            Start for free
            <ArrowRight className="w-4 h-4" />
          </Link>
          <Link
            to="/login"
            className="btn-ghost flex items-center gap-2 px-8 py-4 text-base"
          >
            Sign in
          </Link>
        </div>

        {/* Social proof */}
        <div className="animate-fade-up delay-400 flex items-center gap-6 text-sm text-white/40">
          <div className="flex items-center gap-1.5">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            ))}
            <span className="ml-1">4.9/5</span>
          </div>
          <span>·</span>
          <span>2,000+ creators trust NexusAI</span>
          <span>·</span>
          <span>No credit card required</span>
        </div>

        {/* ── Dashboard Preview ── */}
        <div className="animate-fade-up delay-500 mt-20 w-full max-w-4xl mx-auto">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#0d0d14] z-10 bottom-0 h-1/3 pointer-events-none" />
            <div className="glass-card rounded-2xl p-1 border border-white/10 shadow-2xl shadow-brand-500/10">
              <div className="rounded-xl overflow-hidden bg-[#13131f] p-4">
                {/* Fake browser bar */}
                <div className="flex items-center gap-2 mb-4">
                  <div className="flex gap-1.5">
                    {["#ef4444","#f59e0b","#22c55e"].map(c => (
                      <div key={c} style={{background:c}} className="w-3 h-3 rounded-full opacity-60"/>
                    ))}
                  </div>
                  <div className="flex-1 h-6 rounded-md bg-white/5 ml-2 max-w-xs" />
                </div>
                {/* Fake dashboard */}
                <div className="grid grid-cols-3 gap-3 mb-4">
                  {["24 Posts Generated","98 AI Chats","4.8s Avg Speed"].map((t, i) => (
                    <div key={i} className="glass-card rounded-xl p-3">
                      <p className="text-xs text-white/40 mb-1">{t.split(" ").slice(1).join(" ")}</p>
                      <p className="font-display font-bold text-xl gradient-text">{t.split(" ")[0]}</p>
                    </div>
                  ))}
                </div>
                {/* Fake chat bubbles */}
                <div className="space-y-2.5">
                  <div className="flex justify-end">
                    <div className="bg-brand-500/30 border border-brand-500/20 rounded-2xl rounded-tr-sm px-4 py-2.5 text-sm text-white/80 max-w-xs">
                      Write me a blog intro about AI productivity tools
                    </div>
                  </div>
                  <div className="flex justify-start">
                    <div className="glass-card border border-white/8 rounded-2xl rounded-tl-sm px-4 py-3 text-sm text-white/70 max-w-sm leading-relaxed">
                      <div className="flex items-center gap-1.5 mb-2">
                        <Sparkles className="w-3 h-3 text-brand-400"/>
                        <span className="text-xs text-brand-400 font-medium">NexusAI</span>
                      </div>
                      In a world where every minute counts, AI productivity tools have become the quiet co-pilot behind high-performing teams…
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Features ─────────────────────────────── */}
      <section id="features" className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <span className="section-badge mb-4">Features</span>
            <h2 className="font-display font-bold text-4xl md:text-5xl tracking-tight mb-4">
              Everything you need to
              <br /><span className="gradient-text">create faster</span>
            </h2>
            <p className="text-white/40 max-w-xl mx-auto">
              A complete suite of AI tools designed for modern content creators,
              marketers, and entrepreneurs.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {FEATURES.map(({ icon: Icon, title, desc, color }, i) => (
              <div
                key={i}
                className="glass-card rounded-2xl p-6 group hover:border-white/20 transition-all duration-300 hover:-translate-y-1"
              >
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center mb-4 shadow-lg`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <h3 className="font-display font-semibold text-white mb-2">{title}</h3>
                <p className="text-sm text-white/40 leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── How It Works ─────────────────────────── */}
      <section id="how-it-works" className="py-24 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <span className="section-badge mb-4">Process</span>
            <h2 className="font-display font-bold text-4xl md:text-5xl tracking-tight mb-4">
              Up and running in <span className="gradient-text">minutes</span>
            </h2>
          </div>
          <div className="space-y-6">
            {STEPS.map(({ step, title, desc }, i) => (
              <div key={i} className="flex items-start gap-6 glass-card rounded-2xl p-6 group">
                <div className="font-display font-black text-3xl gradient-text flex-shrink-0 w-12">{step}</div>
                <div>
                  <h3 className="font-display font-semibold text-white mb-1">{title}</h3>
                  <p className="text-sm text-white/40">{desc}</p>
                </div>
                <ChevronRight className="w-5 h-5 text-white/20 ml-auto flex-shrink-0 mt-0.5 group-hover:text-brand-400 transition-colors" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Testimonials ─────────────────────────── */}
      <section id="testimonials" className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <span className="section-badge mb-4">Testimonials</span>
            <h2 className="font-display font-bold text-4xl md:text-5xl tracking-tight mb-4">
              Loved by <span className="gradient-text">creators worldwide</span>
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-5">
            {TESTIMONIALS.map(({ name, role, avatar, rating, text }, i) => (
              <div
                key={i}
                className="glass-card rounded-2xl p-6 flex flex-col gap-4 hover:border-white/20 transition-all duration-300"
              >
                <div className="flex gap-0.5">
                  {[...Array(rating)].map((_, j) => (
                    <Star key={j} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <p className="text-sm text-white/60 leading-relaxed flex-1">"{text}"</p>
                <div className="flex items-center gap-3 pt-2 border-t border-white/8">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-brand-500 to-purple-500 flex items-center justify-center text-xs font-bold text-white flex-shrink-0">
                    {avatar}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">{name}</p>
                    <p className="text-xs text-white/40">{role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────── */}
      <section className="py-24 px-6">
        <div className="max-w-3xl mx-auto text-center">
          <div
            className="rounded-3xl p-12 relative overflow-hidden border border-white/10"
            style={{
              background: "linear-gradient(135deg, rgba(91, 91, 246, 0.15) 0%, rgba(124, 91, 246, 0.1) 100%)",
            }}
          >
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
              <div className="absolute -top-20 -right-20 w-60 h-60 bg-brand-500/20 rounded-full blur-[80px]" />
              <div className="absolute -bottom-20 -left-20 w-60 h-60 bg-purple-500/15 rounded-full blur-[80px]" />
            </div>
            <div className="relative">
              <h2 className="font-display font-bold text-4xl md:text-5xl tracking-tight mb-4">
                Start creating <span className="gradient-text">for free</span>
              </h2>
              <p className="text-white/50 mb-8 max-w-md mx-auto">
                Join 2,000+ creators. 20 free AI generations included. No credit card required.
              </p>
              <Link
                to="/register"
                className="btn-primary inline-flex items-center gap-2 px-8 py-4 text-base"
              >
                Create free account <ArrowRight className="w-4 h-4" />
              </Link>
              <div className="flex items-center justify-center gap-4 mt-6 text-sm text-white/30">
                {["Free forever plan", "No credit card", "Cancel anytime"].map((t, i) => (
                  <span key={i} className="flex items-center gap-1.5">
                    <Check className="w-3.5 h-3.5 text-green-400" /> {t}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Footer ───────────────────────────────── */}
      <footer className="py-10 px-6 border-t border-white/8">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-gradient-to-br from-brand-500 to-purple-600 flex items-center justify-center">
              <Sparkles className="w-3 h-3 text-white" />
            </div>
            <span className="font-display font-semibold text-white text-sm">NexusAI</span>
          </div>
          <p className="text-white/30 text-sm">© 2025 NexusAI. Built with React + Node.js + OpenAI.</p>
          <div className="flex gap-5 text-sm text-white/30">
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
