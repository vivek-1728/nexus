/**
 * hooks/useAI.js
 *
 * Custom React hook for AI features.
 * Encapsulates loading states, error handling,
 * and API calls for all AI operations.
 *
 * Usage:
 *   const { sendMessage, generate, loading, error } = useAI();
 */

import { useState } from "react";
import api from "../utils/api";
import toast from "react-hot-toast";

const useAI = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // ── Send Chat Message ────────────────────────────
  const sendMessage = async (messages) => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.post("/ai/chat", { messages });
      return res.data.message;
    } catch (err) {
      setError(err.message);
      toast.error(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  };

  // ── Generate Content ─────────────────────────────
  const generate = async ({ type, topic, tone, length }) => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.post("/ai/generate", { type, topic, tone, length });
      return res.data.content;
    } catch (err) {
      setError(err.message);
      toast.error(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  };

  // ── Improve Text ─────────────────────────────────
  const improveText = async (text, instruction) => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.post("/ai/improve", { text, instruction });
      return res.data.improved;
    } catch (err) {
      setError(err.message);
      toast.error(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  };

  return { sendMessage, generate, improveText, loading, error };
};

export default useAI;
