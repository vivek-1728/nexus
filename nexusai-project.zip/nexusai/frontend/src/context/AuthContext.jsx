/**
 * context/AuthContext.jsx
 *
 * React Context for authentication state.
 * Provides user, login, logout, and loading state
 * to any component in the tree via useAuth() hook.
 */

import { createContext, useContext, useState, useEffect } from "react";
import api from "../utils/api";
import toast from "react-hot-toast";

// Create the context
const AuthContext = createContext(null);

// ── AuthProvider ─────────────────────────────────────
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true); // true while checking stored token

  // On app load, check if a token exists in localStorage
  // If so, verify it with the backend and restore the session
  useEffect(() => {
    const initAuth = async () => {
      const token = localStorage.getItem("nexusai_token");
      if (token) {
        try {
          const res = await api.get("/auth/me");
          setUser(res.data.user);
        } catch {
          // Token is invalid/expired — clear it
          localStorage.removeItem("nexusai_token");
        }
      }
      setLoading(false);
    };
    initAuth();
  }, []);

  // ── Login ──────────────────────────────────────────
  const login = async (email, password) => {
    const res = await api.post("/auth/login", { email, password });
    const { token, user } = res.data;

    // Persist token so user stays logged in on page refresh
    localStorage.setItem("nexusai_token", token);
    setUser(user);
    toast.success(`Welcome back, ${user.name}! 👋`);
    return user;
  };

  // ── Register ───────────────────────────────────────
  const register = async (name, email, password) => {
    const res = await api.post("/auth/register", { name, email, password });
    const { token, user } = res.data;

    localStorage.setItem("nexusai_token", token);
    setUser(user);
    toast.success(`Account created! Welcome to NexusAI, ${user.name}! 🎉`);
    return user;
  };

  // ── Logout ─────────────────────────────────────────
  const logout = () => {
    localStorage.removeItem("nexusai_token");
    setUser(null);
    toast.success("Logged out successfully.");
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

// ── Custom hook ───────────────────────────────────────
// Usage: const { user, login, logout } = useAuth();
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used inside <AuthProvider>");
  }
  return context;
};
