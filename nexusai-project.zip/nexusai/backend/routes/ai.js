/**
 * routes/ai.js — AI Feature Routes
 *
 * POST /api/ai/chat       → AI chatbot conversation
 * POST /api/ai/generate   → AI content generator
 * POST /api/ai/improve    → AI text improver
 */

const express = require("express");
const OpenAI = require("openai");
const { protect } = require("../middleware/authMiddleware");

const router = express.Router();

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// ── AI Chat ───────────────────────────────────────
// All AI routes are protected — user must be logged in
router.post("/chat", protect, async (req, res, next) => {
  try {
    const { messages } = req.body;

    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: "Messages array is required." });
    }

    // Call OpenAI Chat Completions API
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo", // Use gpt-4 for better results (costs more)
      messages: [
        {
          role: "system",
          content: `You are NexusAI, a helpful AI assistant specializing in 
          content creation, writing assistance, and creative ideation. 
          Be concise, professional, and genuinely helpful. 
          Format responses with markdown when it improves readability.`,
        },
        ...messages, // Include the full conversation history
      ],
      max_tokens: 800,
      temperature: 0.7, // 0 = deterministic, 1 = creative
    });

    const reply = completion.choices[0].message.content;

    res.json({
      message: reply,
      usage: completion.usage, // Show token usage for transparency
    });
  } catch (error) {
    // Handle OpenAI-specific errors
    if (error.code === "insufficient_quota") {
      return res.status(402).json({
        error: "OpenAI API quota exceeded. Please check your billing.",
      });
    }
    next(error);
  }
});

// ── AI Content Generator ──────────────────────────
router.post("/generate", protect, async (req, res, next) => {
  try {
    const { type, topic, tone, length } = req.body;

    // Map content type to a specific prompt template
    const prompts = {
      "blog-post": `Write a ${length || "medium"}-length blog post about "${topic}". 
        Tone: ${tone || "professional"}. 
        Include: engaging title, introduction, 3-4 main sections with headers, conclusion.`,

      "social-post": `Write a compelling ${tone || "engaging"} social media post about "${topic}". 
        Keep it concise, use relevant emojis, add 3-5 hashtags at the end.`,

      "email": `Write a professional email about "${topic}". 
        Tone: ${tone || "formal"}. Include: subject line, greeting, body, closing.`,

      "product-desc": `Write a compelling product description for "${topic}". 
        Tone: ${tone || "persuasive"}. Highlight key benefits, features, and a call-to-action.`,
    };

    const prompt = prompts[type] || `Write content about "${topic}" in a ${tone || "professional"} tone.`;

    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are an expert content writer. Produce high-quality, original content.",
        },
        { role: "user", content: prompt },
      ],
      max_tokens: 1000,
      temperature: 0.8,
    });

    res.json({
      content: completion.choices[0].message.content,
      type,
      topic,
    });
  } catch (error) {
    next(error);
  }
});

// ── AI Text Improver ──────────────────────────────
router.post("/improve", protect, async (req, res, next) => {
  try {
    const { text, instruction } = req.body;

    if (!text) {
      return res.status(400).json({ error: "Text is required." });
    }

    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are an expert editor. Improve the given text as instructed.",
        },
        {
          role: "user",
          content: `${instruction || "Improve this text for clarity and professionalism"}:\n\n${text}`,
        },
      ],
      max_tokens: 600,
      temperature: 0.6,
    });

    res.json({
      improved: completion.choices[0].message.content,
      original: text,
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
