/**
 * routes/auth.js — Authentication Routes
 *
 * POST /api/auth/register  → Create new account
 * POST /api/auth/login     → Login + get JWT token
 * GET  /api/auth/me        → Get current user (protected)
 */

const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { protect } = require("../middleware/authMiddleware");

const router = express.Router();

// ── In-Memory User Store ─────────────────────────
// In a real app, replace this with a database (MongoDB, PostgreSQL, etc.)
// This is fine for learning/demo purposes!
const users = [];

// ── Helper: Generate JWT Token ───────────────────
const generateToken = (userId) => {
  return jwt.sign(
    { id: userId },
    process.env.JWT_SECRET,
    { expiresIn: "7d" } // Token expires in 7 days
  );
};

// ── Register ─────────────────────────────────────
router.post("/register", async (req, res, next) => {
  try {
    const { name, email, password } = req.body;

    // Validation
    if (!name || !email || !password) {
      return res.status(400).json({ error: "All fields are required." });
    }
    if (password.length < 6) {
      return res
        .status(400)
        .json({ error: "Password must be at least 6 characters." });
    }

    // Check if email already exists
    const existingUser = users.find((u) => u.email === email);
    if (existingUser) {
      return res.status(409).json({ error: "Email already in use." });
    }

    // Hash password — never store plain text passwords!
    const hashedPassword = await bcrypt.hash(password, 12);

    // Create user object
    const newUser = {
      id: Date.now().toString(),
      name,
      email,
      password: hashedPassword,
      plan: "free",         // free | pro
      credits: 20,          // AI generation credits
      createdAt: new Date().toISOString(),
    };

    users.push(newUser);

    // Return token + safe user data (never return password!)
    const token = generateToken(newUser.id);
    const { password: _, ...safeUser } = newUser;

    res.status(201).json({
      message: "Account created successfully!",
      token,
      user: safeUser,
    });
  } catch (error) {
    next(error); // Pass to global error handler
  }
});

// ── Login ────────────────────────────────────────
router.post("/login", async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: "Email and password required." });
    }

    // Find user
    const user = users.find((u) => u.email === email);
    if (!user) {
      // Generic message — don't reveal which field is wrong (security!)
      return res.status(401).json({ error: "Invalid email or password." });
    }

    // Compare password with hashed version
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ error: "Invalid email or password." });
    }

    const token = generateToken(user.id);
    const { password: _, ...safeUser } = user;

    res.json({
      message: "Login successful!",
      token,
      user: safeUser,
    });
  } catch (error) {
    next(error);
  }
});

// ── Get Current User (Protected Route) ───────────
// The 'protect' middleware verifies the JWT before this runs
router.get("/me", protect, (req, res) => {
  const user = users.find((u) => u.id === req.userId);
  if (!user) {
    return res.status(404).json({ error: "User not found." });
  }
  const { password: _, ...safeUser } = user;
  res.json({ user: safeUser });
});

module.exports = router;
