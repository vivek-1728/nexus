/**
 * utils/api.js
 *
 * Pre-configured Axios instance.
 * Automatically attaches JWT token to every request.
 * Handles global API errors.
 */

import axios from "axios";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:5000/api",
  timeout: 15000, // 15 second timeout
  headers: {
    "Content-Type": "application/json",
  },
});

// ── Request Interceptor ───────────────────────────────
// Runs before EVERY request — attaches the auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("nexusai_token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// ── Response Interceptor ──────────────────────────────
// Runs after EVERY response — normalizes error format
api.interceptors.response.use(
  (response) => response, // Success — pass through

  (error) => {
    // Extract the error message from the response
    const message =
      error.response?.data?.error ||
      error.message ||
      "An unexpected error occurred.";

    // Auto-logout on 401 Unauthorized (expired token)
    if (error.response?.status === 401) {
      localStorage.removeItem("nexusai_token");
      window.location.href = "/login";
    }

    // Re-throw with clean message
    return Promise.reject(new Error(message));
  }
);

export default api;
