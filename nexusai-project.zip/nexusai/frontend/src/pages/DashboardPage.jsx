/**
 * pages/DashboardPage.jsx
 *
 * Main dashboard shown after login.
 * Shows stats, quick actions, and recent activity.
 */

import { Link } from "react-router-dom";
import { MessageSquare, Wand2, Zap, ArrowRight, Sparkles, TrendingUp } from "lucide-react";
import { useAuth } from "../context/AuthContext";

// ── Stat Card ─────────────────────────────────────────
const StatCard = ({ label, value, icon: Icon, color }) => (
  <div className="glass-card rounded-2xl p-5 flex items-center gap-4">
    <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center flex-shrink-0`}>
      <Icon className="w-5 h-5 text-white" />
    </div>
    <div>
      <p className="text-2xl font-display font-bold text-white">{value}</p>
      <p className="text-xs text-white/40 mt-0.5">{label}</p>
    </div>
  </div>
);

// ── Quick Action Card ─────────────────────────────────
const ActionCard = ({ to, icon: Icon, title, desc, color }) => (
  <Link
    to={to}
    className="glass-card rounded-2xl p-6 flex flex-col gap-3 group hover:border-white/20 transition-all duration-300 hover:-translate-y-1"
  >
    <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center`}>
      <Icon className="w-5 h-5 text-white" />
    </div>
    <div className="flex items-start justify-between">
      <div>
        <h3 className="font-display font-semibold text-white mb-1">{title}</h3>
        <p className="text-sm text-white/40">{desc}</p>
      </div>
      <ArrowRight className="w-4 h-4 text-white/20 group-hover:text-white/60 transition-colors flex-shrink-0 mt-0.5" />
    </div>
  </Link>
);

export default function DashboardPage() {
  const { user } = useAuth();

  // Get greeting based on time of day
  const hour = new Date().getHours();
  const greeting =
    hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";

  return (
    <div className="p-6 md:p-8 max-w-5xl mx-auto">
      {/* ── Header ──────────────────────────────── */}
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-1">
          <Sparkles className="w-4 h-4 text-brand-400" />
          <span className="text-sm text-brand-400 font-medium">Dashboard</span>
        </div>
        <h1 className="font-display font-bold text-3xl text-white">
          {greeting}, {user?.name?.split(" ")[0]} 👋
        </h1>
        <p className="text-white/40 mt-1">Here's an overview of your NexusAI usage.</p>
      </div>

      {/* ── Stats ───────────────────────────────── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard label="Content Generated" value="0" icon={Wand2} color="from-violet-500 to-brand-500" />
        <StatCard label="AI Chat Messages" value="0" icon={MessageSquare} color="from-cyan-500 to-blue-500" />
        <StatCard label="Credits Remaining" value={user?.credits || 20} icon={Zap} color="from-amber-400 to-orange-500" />
        <StatCard label="Days Active" value="1" icon={TrendingUp} color="from-green-400 to-emerald-500" />
      </div>

      {/* ── Quick Actions ────────────────────────── */}
      <div className="mb-8">
        <h2 className="font-display font-semibold text-white mb-4">Quick Actions</h2>
        <div className="grid md:grid-cols-2 gap-4">
          <ActionCard
            to="/chat"
            icon={MessageSquare}
            title="AI Chat Assistant"
            desc="Ask questions, brainstorm ideas, get writing help."
            color="from-cyan-500 to-blue-500"
          />
          <ActionCard
            to="/generate"
            icon={Wand2}
            title="Generate Content"
            desc="Create blog posts, emails, social posts in seconds."
            color="from-violet-500 to-brand-500"
          />
        </div>
      </div>

      {/* ── Plan Info ────────────────────────────── */}
      <div
        className="rounded-2xl p-6 border border-brand-500/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
        style={{ background: "rgba(91, 91, 246, 0.08)" }}
      >
        <div>
          <p className="text-sm text-brand-400 font-medium mb-1">Your Plan</p>
          <p className="font-display font-bold text-white text-xl capitalize">{user?.plan} Plan</p>
          <p className="text-sm text-white/40 mt-0.5">
            {user?.credits} AI credits remaining
          </p>
        </div>
        <button className="btn-primary flex items-center gap-2 text-sm px-5 py-2.5 flex-shrink-0">
          Upgrade to Pro <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}
