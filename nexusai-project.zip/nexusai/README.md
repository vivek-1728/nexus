# 🚀 NexusAI — Full-Stack AI Content Studio

A professional, production-grade AI-powered web application built with:
- **Frontend**: React 18 + Vite + Tailwind CSS
- **Backend**: Node.js + Express.js
- **AI**: OpenAI GPT-3.5/GPT-4

---

## 📁 Complete Project Structure

```
nexusai/
│
├── frontend/                    ← React app (Vite)
│   ├── index.html
│   ├── vite.config.js
│   ├── tailwind.config.js
│   ├── postcss.config.js
│   ├── package.json
│   ├── .env.example             ← Copy to .env
│   └── src/
│       ├── main.jsx             ← App entry point
│       ├── App.jsx              ← Root with React Router
│       │
│       ├── pages/               ← One file per page/route
│       │   ├── LandingPage.jsx  ← Public marketing page
│       │   ├── LoginPage.jsx
│       │   ├── RegisterPage.jsx
│       │   ├── DashboardPage.jsx
│       │   ├── ChatPage.jsx     ← AI chat interface
│       │   └── GeneratePage.jsx ← AI content generator
│       │
│       ├── components/
│       │   ├── layout/
│       │   │   └── Layout.jsx   ← Sidebar + main layout
│       │   └── ui/
│       │       └── LoadingSpinner.jsx
│       │
│       ├── context/
│       │   └── AuthContext.jsx  ← Global auth state (React Context)
│       │
│       ├── hooks/
│       │   └── useAI.js         ← Custom hook for AI API calls
│       │
│       ├── utils/
│       │   └── api.js           ← Axios instance + interceptors
│       │
│       └── styles/
│           └── globals.css      ← Tailwind + custom styles
│
└── backend/                     ← Express API server
    ├── server.js                ← Entry point
    ├── package.json
    ├── .env.example             ← Copy to .env
    │
    ├── routes/
    │   ├── auth.js              ← /api/auth/* (login, register, me)
    │   └── ai.js                ← /api/ai/* (chat, generate, improve)
    │
    └── middleware/
        ├── authMiddleware.js    ← JWT protection
        └── errorHandler.js      ← Global error handler
```

---

## ⚡ Quick Start

### Prerequisites
- Node.js v18 or higher (`node --version` to check)
- npm or yarn
- OpenAI API key (get one at https://platform.openai.com)

### Step 1: Clone / download the project

```bash
cd nexusai
```

### Step 2: Set up the Backend

```bash
cd backend

# Install dependencies
npm install

# Create environment file
cp .env.example .env

# Edit .env — fill in your values:
# OPENAI_API_KEY=sk-your-key-here
# JWT_SECRET=some-long-random-string-32-chars-minimum

# Start the server (development mode with auto-reload)
npm run dev
```

Backend will run at: **http://localhost:5000**

Test it: http://localhost:5000/api/health

### Step 3: Set up the Frontend

```bash
# In a new terminal tab
cd frontend

# Install dependencies
npm install

# Create environment file
cp .env.example .env

# .env should contain:
# VITE_API_URL=http://localhost:5000/api

# Start the dev server
npm run dev
```

Frontend will run at: **http://localhost:5173**

---

## 🌐 API Reference

### Auth Endpoints

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| POST | /api/auth/register | Create account | No |
| POST | /api/auth/login | Login + get token | No |
| GET | /api/auth/me | Get current user | Yes |

### AI Endpoints

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| POST | /api/ai/chat | AI conversation | Yes |
| POST | /api/ai/generate | Content generation | Yes |
| POST | /api/ai/improve | Text improvement | Yes |

### Example API Request

```javascript
// Login
fetch('http://localhost:5000/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email: 'user@test.com', password: 'password123' })
})

// Protected AI request
fetch('http://localhost:5000/api/ai/chat', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
  },
  body: JSON.stringify({
    messages: [{ role: 'user', content: 'Hello!' }]
  })
})
```

---

## 🚀 Deployment

### Frontend → Vercel

1. Push your `frontend/` folder to a GitHub repository
2. Go to https://vercel.com → New Project → Import your repo
3. Set **Root Directory** to `frontend`
4. Add Environment Variable: `VITE_API_URL=https://your-backend.onrender.com/api`
5. Click Deploy ✓

### Backend → Render

1. Push your `backend/` folder to GitHub
2. Go to https://render.com → New Web Service
3. Connect your repo, set Root Directory to `backend`
4. Set Build Command: `npm install`
5. Set Start Command: `node server.js`
6. Add Environment Variables:
   - `OPENAI_API_KEY=sk-...`
   - `JWT_SECRET=your-secret`
   - `FRONTEND_URL=https://your-app.vercel.app`
   - `NODE_ENV=production`
7. Deploy ✓

---

## 🔒 Environment Variables Reference

### Backend `.env`
```
PORT=5000
NODE_ENV=development
JWT_SECRET=          # Random 32+ char string
OPENAI_API_KEY=      # From platform.openai.com
FRONTEND_URL=        # Your frontend URL (for CORS)
```

### Frontend `.env`
```
VITE_API_URL=        # Your backend URL + /api
```

---

## 💡 Key Concepts Explained

### 1. JWT Authentication Flow
```
User registers/logs in → Backend creates JWT → 
Frontend stores in localStorage → 
Every request sends "Authorization: Bearer <token>" →
Backend verifies token → Allows access
```

### 2. React Context (AuthContext)
- Stores user state globally
- All components can access `useAuth()` hook
- No need to pass user data via props

### 3. Custom Hooks
- `useAI()` encapsulates all AI API logic
- Reusable across any page
- Handles loading states and errors automatically

### 4. Protected Routes
- `<ProtectedRoute>` checks if user is logged in
- If not logged in → redirects to /login
- Prevents unauthorized access to dashboard

### 5. API Interceptors (Axios)
- Auto-attaches JWT to every request
- Auto-redirects to login on 401 errors
- Centralized error handling

---

## 🎯 Next Steps to Impress Clients

1. **Add a real database**: Replace in-memory users with MongoDB or PostgreSQL
2. **Stream AI responses**: Use OpenAI streaming for real-time typing effect
3. **Add content history**: Save generated content to DB, show in dashboard
4. **Add pricing page**: Stripe integration for paid plans
5. **Add usage tracking**: Count credits, enforce limits per plan
6. **Add image generation**: DALL-E 3 integration for AI images
7. **Export to PDF/Word**: Let users download generated content
8. **Add team features**: Workspaces, invite members, share content
9. **Dark/light mode toggle**: Accessibility improvement
10. **Add tests**: Jest + React Testing Library for frontend

---

## 📦 Tech Stack Summary

| Layer | Technology | Why |
|-------|-----------|-----|
| Frontend | React 18 | Industry standard, component-based |
| Routing | React Router v6 | SPA navigation |
| Styling | Tailwind CSS | Utility-first, fast, responsive |
| HTTP Client | Axios | Better than fetch, interceptors |
| Notifications | react-hot-toast | Beautiful toast messages |
| Icons | lucide-react | Clean, consistent icon set |
| Build Tool | Vite | Blazing fast dev server |
| Backend | Express.js | Simple, flexible Node framework |
| Auth | JWT + bcrypt | Stateless, secure |
| AI | OpenAI API | Best-in-class language models |
| Security | helmet + rate-limit | Production security basics |
