/**
 * middleware/errorHandler.js
 *
 * Global error handler — catches ALL unhandled errors
 * and returns a consistent JSON error response.
 *
 * Express knows this is an error handler because it has 4 params: (err, req, res, next)
 */

const errorHandler = (err, req, res, next) => {
  console.error("❌ Error:", err.message);

  // Default to 500 Internal Server Error
  const statusCode = err.statusCode || 500;
  const message =
    process.env.NODE_ENV === "production"
      ? "Something went wrong. Please try again." // Hide details in production
      : err.message; // Show full error in development

  res.status(statusCode).json({
    error: message,
    ...(process.env.NODE_ENV !== "production" && { stack: err.stack }),
  });
};

module.exports = { errorHandler };
