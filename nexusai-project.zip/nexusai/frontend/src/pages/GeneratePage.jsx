/**
 * pages/GeneratePage.jsx
 *
 * AI content generation tool.
 * User fills a form → AI generates content → User can copy/edit.
 */

import { useState } from "react";
import { Wand2, Copy, Check, Sparkles, RefreshCw } from "lucide-react";
import useAI from "../hooks/useAI";
import LoadingSpinner from "../components/ui/LoadingSpinner";

// ── Config ────────────────────────────────────────────
const CONTENT_TYPES = [
  { value: "blog-post",    label: "📝 Blog Post" },
  { value: "social-post",  label: "📱 Social Media Post" },
  { value: "email",        label: "📧 Email" },
  { value: "product-desc", label: "🛍️ Product Description" },
];

const TONES = [
  { value: "professional", label: "Professional" },
  { value: "casual",       label: "Casual" },
  { value: "persuasive",   label: "Persuasive" },
  { value: "friendly",     label: "Friendly" },
  { value: "formal",       label: "Formal" },
  { value: "creative",     label: "Creative" },
];

const LENGTHS = [
  { value: "short",  label: "Short" },
  { value: "medium", label: "Medium" },
  { value: "long",   label: "Long" },
];

// ── Select component ──────────────────────────────────
const SelectField = ({ label, value, onChange, options }) => (
  <div>
    <label className="block text-sm text-white/60 mb-2 font-medium">{label}</label>
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="input-field"
    >
      {options.map(({ value: v, label: l }) => (
        <option key={v} value={v} style={{ background: "#1a1a2e" }}>
          {l}
        </option>
      ))}
    </select>
  </div>
);

// ── Main Page ─────────────────────────────────────────
export default function GeneratePage() {
  const { generate, loading } = useAI();

  const [form, setForm] = useState({
    type: "blog-post",
    topic: "",
    tone: "professional",
    length: "medium",
  });
  const [output, setOutput] = useState("");
  const [copied, setCopied] = useState(false);
  const [wordCount, setWordCount] = useState(0);

  const handleGenerate = async () => {
    if (!form.topic.trim()) return;
    setOutput("");
    const result = await generate(form);
    if (result) {
      setOutput(result);
      setWordCount(result.trim().split(/\s+/).length);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-6 md:p-8 max-w-5xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="font-display font-bold text-2xl text-white flex items-center gap-2">
          <Wand2 className="w-5 h-5 text-brand-400" />
          Content Generator
        </h1>
        <p className="text-white/40 mt-1 text-sm">Fill in the form and let AI do the writing.</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* ── Left: Form ──────────────────────────── */}
        <div className="space-y-5">
          <div className="glass-card rounded-2xl p-6 space-y-5">
            {/* Content Type */}
            <div>
              <label className="block text-sm text-white/60 mb-3 font-medium">Content Type</label>
              <div className="grid grid-cols-2 gap-2">
                {CONTENT_TYPES.map(({ value, label }) => (
                  <button
                    key={value}
                    onClick={() => setForm({ ...form, type: value })}
                    className={`
                      px-3 py-2.5 rounded-xl text-sm font-medium text-left transition-all
                      ${form.type === value
                        ? "bg-brand-500/20 border border-brand-500/40 text-brand-300"
                        : "glass-card border border-white/8 text-white/50 hover:text-white hover:border-white/20"
                      }
                    `}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {/* Topic */}
            <div>
              <label className="block text-sm text-white/60 mb-2 font-medium">Topic / Subject</label>
              <textarea
                value={form.topic}
                onChange={(e) => setForm({ ...form, topic: e.target.value })}
                placeholder={
                  form.type === "blog-post"    ? "e.g. The future of AI in healthcare" :
                  form.type === "social-post"  ? "e.g. Our new product launch sale" :
                  form.type === "email"        ? "e.g. Following up on the project proposal" :
                  "e.g. Wireless noise-cancelling headphones"
                }
                rows={3}
                className="input-field resize-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <SelectField
                label="Tone"
                value={form.tone}
                onChange={(v) => setForm({ ...form, tone: v })}
                options={TONES}
              />
              <SelectField
                label="Length"
                value={form.length}
                onChange={(v) => setForm({ ...form, length: v })}
                options={LENGTHS}
              />
            </div>

            <button
              onClick={handleGenerate}
              disabled={!form.topic.trim() || loading}
              className="btn-primary w-full flex items-center justify-center gap-2 py-3.5"
            >
              {loading ? (
                <><LoadingSpinner size="sm" /> Generating...</>
              ) : (
                <><Sparkles className="w-4 h-4" /> Generate Content</>
              )}
            </button>
          </div>

          {/* Tips */}
          <div className="glass-card rounded-2xl p-4 text-xs text-white/30 space-y-1.5">
            <p className="font-medium text-white/50 mb-2">💡 Tips for better results</p>
            <p>• Be specific: "5 benefits of cold brew coffee for busy professionals" beats "coffee"</p>
            <p>• Include your audience: "...for small business owners" helps focus the output</p>
            <p>• Regenerate if unhappy — each generation is unique</p>
          </div>
        </div>

        {/* ── Right: Output ────────────────────────── */}
        <div className="flex flex-col">
          <div className="glass-card rounded-2xl flex-1 flex flex-col min-h-[400px]">
            {/* Output header */}
            <div className="flex items-center justify-between p-4 border-b border-white/8">
              <div className="flex items-center gap-2">
                <Wand2 className="w-4 h-4 text-brand-400" />
                <span className="text-sm font-medium text-white">Generated Content</span>
              </div>
              {output && (
                <div className="flex items-center gap-3">
                  <span className="text-xs text-white/30">{wordCount} words</span>
                  <button
                    onClick={handleGenerate}
                    disabled={loading}
                    className="p-1.5 rounded-lg text-white/30 hover:text-white/60 hover:bg-white/5 transition-all"
                    title="Regenerate"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={handleCopy}
                    className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-brand-500/20 text-brand-300 hover:bg-brand-500/30 transition-all"
                  >
                    {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    {copied ? "Copied!" : "Copy"}
                  </button>
                </div>
              )}
            </div>

            {/* Output content */}
            <div className="flex-1 p-4 md:p-6 overflow-y-auto">
              {loading ? (
                <div className="h-full flex flex-col items-center justify-center gap-4 text-center">
                  <LoadingSpinner size="lg" />
                  <div>
                    <p className="text-sm text-white/60 font-medium">Writing your content…</p>
                    <p className="text-xs text-white/30 mt-1">This usually takes 3–8 seconds</p>
                  </div>
                </div>
              ) : output ? (
                <div className="prose prose-invert prose-sm max-w-none">
                  <pre className="whitespace-pre-wrap font-body text-sm text-white/70 leading-relaxed">
                    {output}
                  </pre>
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-center py-8">
                  <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center mb-3">
                    <Wand2 className="w-6 h-6 text-white/20" />
                  </div>
                  <p className="text-sm text-white/30 max-w-xs">
                    Fill in the form on the left and click "Generate Content" to see the magic happen.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
